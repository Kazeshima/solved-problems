"""Independent, simple exact DP using all subsets, not C++ mixed-radix code.
Also independently verify per-schedule lower-bound certificates.
"""
import argparse
import itertools
from pathlib import Path

def gaps(n, mask):
    return [h for h in range(n-1, 1, -1) if mask & (1 << (h-2))] + [1]

def literal_cost(a, H):
    a = list(a)
    c = 0
    for h in H:
        for r in range(h):
            for i in range(r+h, len(a), h):
                j = i
                while j >= h:
                    c += 1
                    if a[j-h] < a[j]:
                        break
                    a[j-h], a[j] = a[j], a[j-h]
                    j -= h
    assert a == sorted(a)
    return c

def exact_full(n, H):
    # For each original subset S, propagate S and the newly added rank.
    # Binary pass output depends only on each residue's small-key count.
    full = (1 << n) - 1
    cm = {h: [sum(1 << i for i in range(r,n,h)) for r in range(h)] for h in H}
    pred = {h: [sum(1 << j for j in range(i%h,i,h)) for i in range(n)] for h in H}
    pack = {h: [[sum(1 << (r+i*h) for i in range(k))
                 for k in range(cm[h][r].bit_count()+1)] for r in range(h)] for h in H}
    dp = [-1] * (full+1)
    dp[0] = 0
    for S in range(full):
        # Precompute each pass input subset and its chain counts.
        A = S
        cache = []
        for h in H:
            counts = [(A & m).bit_count() for m in cm[h]]
            cache.append((h, A, counts))
            A = sum(pack[h][r][k] for r,k in enumerate(counts))
        unused = full ^ S
        while unused:
            bit = unused & -unused
            unused ^= bit
            x = bit.bit_length()-1
            c = dp[S]
            for h,A,counts in cache:
                small = (A & pred[h][x]).bit_count()
                c += x//h-small + (small > 0)
                x = x%h + h*counts[x%h]
            if c > dp[S|bit]: dp[S|bit] = c
    return dp[full]

def verify_certificate(path, check_upper=True):
    P = {}; mask_expected=0; winners=[]; ended=False
    with open(path) as f:
        tag,n,opt=f.readline().split(); n=int(n); opt=int(opt)
        assert tag=='N'
        for line in f:
            t,*parts=line.split()
            assert not ended
            if t=='P':
                i,*w=map(int,parts); assert i not in P and sorted(w)==list(range(n)); P[i]=w; continue
            if t=='END':
                assert int(parts[0])==mask_expected==1<<(n-2)
                ended=True; continue
            m=int(parts[0]); assert m==mask_expected; mask_expected+=1; H=gaps(n,m)
            if t=='B': assert sum(n-h for h in H)>opt
            elif t=='X': assert literal_cost(P[int(parts[1])], H)>opt
            elif t=='O':
                if check_upper: assert exact_full(n,H)==opt
                winners.append(H)
            else: raise ValueError(t)
        assert ended and winners
    print(f'certificate {path}: n={n}, min={opt}, coverage={mask_expected}, distinct witnesses={len(P)}, winners={winners}, upper_checked={check_upper}',flush=True)

def check_small(max_n):
    checked=0; nperms=0
    for n in range(2,max_n+1):
        allp=list(itertools.permutations(range(n)))
        for mask in range(1<<(n-2)):
            H=gaps(n,mask)
            actual=max(literal_cost(p,H) for p in allp)
            dp=exact_full(n,H)
            assert actual==dp,(n,H,actual,dp)
            checked+=1;nperms+=len(allp)
        print(f'checked n={n}, cumulative schedules={checked}, permutations-times-schedules={nperms}',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--small',type=int); ap.add_argument('--certificate',nargs='*'); ap.add_argument('--skip-upper',action='store_true'); ap.add_argument('--exact',nargs='+',type=int)
    a=ap.parse_args()
    if a.small: check_small(a.small)
    if a.certificate:
        for p in a.certificate: verify_certificate(p,not a.skip_upper)
    if a.exact:
        n,*H=a.exact; print(f'independent exact n={n} gaps={H} max={exact_full(n,H)}',flush=True)
