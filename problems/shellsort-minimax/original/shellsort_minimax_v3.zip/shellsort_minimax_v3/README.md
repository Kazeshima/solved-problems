# Exact minimax gap selection in Shellsort — round 3

**Date:** 2026-11-25. Research draft, not a Lean-verified release.

## Model and scope

Input: any permutation of ranks 0,...,n-1, n >= 2. A legal table is a strictly decreasing list of positive integer gaps < n ending in 1. Each pass performs ordinary gapped insertion sort; charge actual comparisons between keys, including the final unsuccessful comparison if the insertion stops before the front of its chain. Do not charge index checks, writes, or comparisons against a sentinel. The objective is `min_H max_A C(H,A)` over all legal tables. The results do not address nondecreasing or adaptive tables, duplicate keys, other insertion implementations, or the asymptotic optimum over n.

## 1. Threshold path theorem (mathematical proof)

For a permutation A, write `S_k = { i | A[i] < k }`. The sequence from S_0 to S_n is a maximal chain of the Boolean lattice of subsets of [n], and every maximal chain is uniquely produced by one permutation: set A[x]=k when x is the element added at step k. All counts below refer to positions before a given pass.

For h >= 1, define T_h(S) to put the |S intersect R_r| selected positions at the front of residue chain R_r = (r,r+h,...), for each r. This preserves size and is monotone under inclusion. In particular if U = S union {x}, x not in S, then T_h(U) differs from T_h(S) by exactly the position `x%h + h*|S intersect R_(x%h)|`. Thresholding and h-sorting commute: h-sorting arranges the smaller keys first, and preserves the multiset in each residue. The statement is true for the full sorted array, irrespective of which correct insertion-sort implementation produced it.

At the start of pass j, use the transported pair of adjacent thresholds, S and S union {x}, for ranks k and k+1. The singleton difference x is the current position of key k. Let t=floor(x/h_j) count earlier slots in its residue, and s count those slots belonging to S. When that key is inserted, all t original predecessors in the residue have been sorted; none of the later original keys has been used in that chain. Exactly t-s comparisons succeed and shift a larger key; one further comparison fails iff s>0. The cost charged to this insertion is therefore `t-s+(s>0)`. This is valid at t=0 as well, where the key is not inserted and the charge is zero. Each executed key comparison is charged exactly once, to the key being inserted, regardless of the order in which the separate residue chains are visited.

Define the edge weight w_H(S,S union {x}) by summing this expression over the passes, propagating the small-position set S and singleton position x by T_h and the formula above. It depends only on the two adjacent thresholds, not on the rest of the rank assignment. Thus the exact number of comparisons on permutation A is the sum of these weights over its maximal chain. A longest path in the subset lattice gives the exact worst count:

    D[empty] = 0
    D[S] = max_{x in S} (D[S - {x}] + w_H(S - {x}, S)).

The recurrence follows by conditioning on the last added position. Every path is an input, so the maximum is attainable; predecessor pointers reconstruct a maximizer. The reversed (forward propagation) recurrence is identical.

There are 2^n states and n*2^(n-1) edges. For each S, scanning its n positions per pass builds the binary images and prefix counts in O(p*n) word operations. With these counts, each outgoing edge costs O(p), since each new singleton location is propagated by its residue count. Hence O(p*n*2^n) operations for a fixed table, O(2^n + p*n) working words if one computes local counts on the fly, and O(n^2*4^n) operations for a naive search over all 2^(n-2) legal tables. These are arithmetic/word-operation bounds; bit complexity and actual memory of particular implementations differ. The C++ code uses packed 32-bit positions, precomputes images, and restricts n to <=26.

## 2. Compression of the first pass

Let the first gap be h and let m_r be the length of residue chain r. For a fixed assignment of keys to the h chains, the first pass always produces the same output. Reversing each resulting increasing chain gives a legal input that attains the maximum first-pass cost sum_r binom(m_r,2). This can be done independently for every assignment, without changing any later pass.

It is therefore sufficient to optimize over the h-sorted outputs. Their maximal threshold chains lie in the product of chains of sizes m_r+1: a state has digits d_r in [0,m_r], and selects the first d_r positions of residue r. Increasing one digit adds exactly one rank. Every product-chain path corresponds to one h-sorted output and hence to an actual worst-first-pass input via reversing the chains. Applying the same recurrence to the remaining gaps is exact. The number of states is M_h = (q+2)^r(q+1)^(h-r), n=qh+r. It is never larger than 2^n. The compressed C++ solver adds the first-pass maximum and reconstructs an actual original witness; every reconstruction is checked by literal execution. No assumption about divisibility or compatibility of consecutive gap sizes is used.

## 3. Global optimum and certificates

Enumerate masks 0,...,2^(n-2)-1. Bit h-2 indicates the presence of gap h (2 <= h < n), and gap 1 is mandatory. The schedule is executed in decreasing order. This enumerates each legal sequence exactly once. A pass requires at least n-h comparisons, so sum(n-h) is a valid baseline lower bound. A literal execution on ANY permutation is also a valid lower bound, even if found by a heuristic. The search discards a table only when such a lower bound exceeds the incumbent (ties mode), otherwise computes an exact maximum. Thus all minimizers, including ties, are found. The seed is just an initial table and its upper bound is obtained by exact DP, not by trusting the literature.

Certificate format: `N n U` specifies candidate optimum; `P id p0 ... p(n-1)` introduces an actual permutation; `B mask` proves its baseline exceeds U; `X mask id` proves its literal execution exceeds U; `O mask` designates a proposed winner, whose maximum must be independently recomputed. `END count` confirms coverage. The verifier checks every mask in consecutive order, verifies every permutation and comparison count, and recomputes the exact upper and lower bound for each O using a separate full-subset DP. An O cannot certify an optimum by itself; the verified bounds for all other masks are necessary. No cryptographic or statistical assumption is made.

`minimax.cpp` is the original mixed-radix solver. `minimax_fast.cpp` adds deterministic bounded local witness search; no heuristic rejection is accepted without a literal witness. `oracle.py` uses independent literal swap-based insertion sort and a full-subset DP with explicit singleton propagation rather than C++'s XOR of prefix images. It also independently validates all certificate masks. `validation_small.txt` tests against actual exhaustive permutations for every legal table at n=2,...,7.

## 4. Further theorem: full distribution

Let F_empty(z)=1. For S nonempty,

    F_S(z) = sum_{x in S} z^w(S-{x}, S) * F_(S-{x})(z).

Every path is one permutation and the exponent is its cost, hence F_[n](z) is the full counting polynomial for comparisons. Its degree is the maximum; F'(1)/n! is the mean; (F''(1)+F'(1))/n! minus the square of the mean is the variance. The uniform mean can also be computed directly: an edge leaving a subset of cardinality k occurs on k!(n-k-1)! of the n! maximal paths. Multiply each edge weight by this probability and sum. The recurrence for the first two moments needs only count, sum, and squared sum per state. Computing the full polynomial requires additional work proportional to its coefficient range. The first-pass *maximizing* compression is not valid for the complete distribution without including the distribution of first-pass internal costs.

## 5. Reproduction

```
g++ -std=c++20 -O3 -march=native minimax.cpp -o minimax
./minimax 17 ties
./minimax 20 exact 11 7 5 1
./minimax 17 cert cert17.txt
python oracle.py --small 7
python oracle.py --certificate cert17.txt cert18.txt cert19.txt
```

The optional fast implementation uses the same arguments. Compile it as `g++ -std=c++20 -O3 -march=native minimax_fast.cpp -o minimax_fast`.

## 6. Lean status — important

`BooleanLattice.lean` contains draft statements and proof scripts for generic Bellman upper bounds and attainment, subset-lattice viability, threshold binary-pass monotonicity, the insertion charge bound, and the maximum of the explicit edge-weight model. `Executable.lean` contains draft executable Lean definitions of ordinary insertion sort, bit-mask threshold passes, edge weight, exact full DP and witness checks. `lakefile.toml` pins Lean/mathlib v4.19.0, consistent with round 2.

The Lean toolchain is absent; direct GitHub network access fails with DNS error, and the alternative download route failed. No Lean compiler or kernel was run. There are no deliberate proof placeholders or new axioms in these drafts, but elaboration/build failures are possible. **The following bridges are still open:** (i) threshold/actual h-sort commutation and singleton transport, (ii) actual executed comparisons equal the insertion charges, (iii) full paths correspond bijectively to rank permutations, (iv) optimized DP/Lean witness-certificate verification. The mathematical proofs are given above; the source is not an end-to-end Lean proof of any reported minimax value. Do not present it as such.

To attempt compilation externally: `lake exe cache get && lake build`; then repair any draft errors, formalize the four bridges, and prove that checked finite certificates imply the numerical optimum. The `#eval` checks are not kernel proofs of the large values. The computational certificates and Python validation are independent of Lean.

## 7. Prior art / originality boundary

- Ying Wai Lee, *Optimal Gap Sequences in Shellsort for n <= 16 Elements* (2021), https://arxiv.org/abs/2112.11127. This is the exact prior problem and establishes n<=16, listing best-known candidates for n=17..30.
- https://github.com/mkdokken/ShellSort : updated heuristic search results include the same candidate optimal values and schedules for n=17 onward; its README explicitly disclaims certainty for n>16. The numbers themselves are therefore not new guesses. The contribution is exact certification and a new candidate method, subject to further novelty review.
- https://github.com/EternalYMZ/Project-S and https://github.com/LeanPool/lean-pool : already contain substantial Shellsort average-case formalizations; do not confuse those with the worst-case exact finite objective.
- Du and Wan, *Shellsort with O(n log n) Average-Case Complexity*, https://arxiv.org/abs/2611.27671, a recent average-case claim, different objective.
- Poonen, *The Worst Case in Shellsort and Related Algorithms*, https://doi.org/10.1006/jagm.1993.1032, asymptotic worst-case lower bounds.

Searches used public arXiv and web indices of DBLP, Semantic Scholar, OpenAlex, OEIS, plus GitHub code search (including direct connector queries for Shellsort/subset dynamic programming, minimax optimal gaps, binary lattice, exact worst-case permutations). No matching exact Boolean-lattice method or independently certified n>=17 result was found; this is not an exhaustive guarantee over all databases, unindexed code, paywalled material, or unpublished work. The zero-one threshold principle and generic Bellman recurrence are classical; the candidate contribution is their precise comparison-cost edge decomposition and application to exact Shellsort minimax certification. This method does not rely on a claimed OpenAI-specific theorem.

Prior rounds' mathematical drafts are in ROUND1.md and ROUND2.md. The new threshold proof stands independently of those drafts.

## 8. Completed global search results

All comparisons are literal key comparisons. Gap tables are shown in descending order. The original solver's `ties` mode was used for n=2,...,20, and the fast certificate solver for n=21. The search at n=21 with the original slower solver was interrupted after the complete fast certificate was produced; its partial log is not a proof and is excluded from the archive.

| n | Minimum worst cost | All schedules | Number of winners | All minimizing schedules |
|---:|---:|---:|---:|---|
| 2 | 1 | 1 | 1 | 1 |
| 3 | 3 | 2 | 1 | 1 |
| 4 | 6 | 4 | 1 | 1 |
| 5 | 10 | 8 | 3 | 1; 3,1; 4,3,1 |
| 6 | 14 | 16 | 3 | 4,1; 5,3,1; 5,4,1 |
| 7 | 18 | 32 | 1 | 6,4,1 |
| 8 | 23 | 64 | 1 | 7,5,1 |
| 9 | 29 | 128 | 5 | 4,3,1; 7,4,1; 8,5,1; 8,6,1; 8,7,5,1 |
| 10 | 35 | 256 | 3 | 9,6,1; 9,8,5,1; 9,8,6,1 |
| 11 | 41 | 512 | 2 | 5,4,1; 10,9,6,1 |
| 12 | 48 | 1,024 | 2 | 11,7,3,1; 11,10,7,1 |
| 13 | 56 | 2,048 | 12 | 4,3,1; 5,2,1; 6,5,1; 7,5,1; 9,7,5,1; 10,6,1; 11,7,5,1; 11,9,6,1; 11,10,6,1; 12,10,7,1; 12,11,7,1; 12,11,8,1 |
| 14 | 64 | 4,096 | 23 | 4,3,1; 5,3,1; 7,5,4,1; 8,6,5,1; 8,7,3,1; 9,7,4,1; 10,7,6,1; 11,5,4,1; 11,7,3,1; 11,7,5,1; 11,9,4,1; 12,7,5,4,1; 12,8,5,1; 13,5,2,1; 13,6,5,1; 13,7,5,4,1; 13,9,7,4,1; 13,10,6,1; 13,11,7,1; 13,11,7,5,1; 13,11,8,1; 13,11,9,6,1; 13,12,8,1 |
| 15 | 71 | 8,192 | 9 | 7,3,1; 7,5,4,1; 8,6,5,1; 8,7,3,1; 9,7,4,1; 13,7,5,1; 14,8,5,1; 14,8,6,5,1; 14,9,4,1 |
| 16 | 78 | 16,384 | 1 | 9,7,4,1 |
| 17 | 86 | 32,768 | 1 | 9,6,4,1 |
| 18 | 94 | 65,536 | 1 | 17,9,6,4,1 |
| 19 | 103 | 131,072 | 1 | 9,7,4,1 |
| 20 | 112 | 262,144 | 1 | 11,7,5,1 |
| 21 | 121 | 524,288 | 2 | 9,7,4,1; 20,9,7,4,1 |

The five sizes n=17,...,21 cover 1,015,808 schedules in total. The n=21 certificate uses 209,257 baseline exclusions, 314,791 literal witness exclusions (of which 5,194 were discovered by local search), and 240 exact DP evaluations, including two winners. All certificate files for these five sizes have the final END record. Validation logs record the exact independent checks that completed. The rank witness for each new optimal table is recorded in `winner_witnesses.txt`.

Independent Python certificate verification completed for all n=17,...,21, including full-subset DP upper bounds for every winner.
